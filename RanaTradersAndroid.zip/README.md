# Rana Traders

Wholesale Grocery Management Android App

## Current version
1.0 starter

## Modules
- Products & Stock
- Customers
- Suppliers
- Purchase
- Sales
- Expenses
- Profit & Loss
- Reports
- Backup & Restore
- Settings

## Technology
- Kotlin
- Jetpack Compose
- Material 3
- Android SDK

## Next development
The next version will add local database storage, product/customer/supplier forms,
stock calculation, purchase/sales invoices, ledgers, expenses, profit & loss,
reports, backup/restore and WhatsApp sharing.
