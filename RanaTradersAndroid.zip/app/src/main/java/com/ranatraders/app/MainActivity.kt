package com.ranatraders.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.compose.*
import androidx.compose.ui.unit.sp

data class Module(val title: String, val subtitle: String, val icon: ImageVector, val route: String)

val modules = listOf(
    Module("Products", "Products & stock", Icons.Default.Inventory2, "products"),
    Module("Customers", "Customer accounts", Icons.Default.People, "customers"),
    Module("Suppliers", "Supplier accounts", Icons.Default.LocalShipping, "suppliers"),
    Module("Purchase", "Purchase entries", Icons.Default.ShoppingCart, "purchase"),
    Module("Sales", "Sales & invoices", Icons.Default.PointOfSale, "sales"),
    Module("Expenses", "Business expenses", Icons.Default.ReceiptLong, "expenses"),
    Module("Profit & Loss", "Business summary", Icons.Default.Assessment, "profit"),
    Module("Reports", "Daily & monthly reports", Icons.Default.BarChart, "reports"),
    Module("Backup", "Backup & restore", Icons.Default.Backup, "backup"),
    Module("Settings", "App settings", Icons.Default.Settings, "settings")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            RanaTradersTheme {
                RanaTradersApp()
            }
        }
    }
}

@Composable
fun RanaTradersApp() {
    val navController = rememberNavController()

    NavHost(navController = navController, startDestination = "dashboard") {
        composable("dashboard") {
            DashboardScreen(
                onModuleClick = { navController.navigate(it) }
            )
        }
        modules.forEach { module ->
            composable(module.route) {
                ModuleScreen(
                    title = module.title,
                    subtitle = module.subtitle,
                    icon = module.icon,
                    onBack = { navController.popBackStack() }
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(onModuleClick: (String) -> Unit) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text("Rana Traders", fontWeight = FontWeight.Bold)
                        Text("Wholesale Grocery Management", fontSize = 12.sp)
                    }
                },
                actions = {
                    IconButton(onClick = { onModuleClick("settings") }) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            Spacer(Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SummaryCard("Today Sales", "Rs 0", Modifier.weight(1f))
                SummaryCard("Today Profit", "Rs 0", Modifier.weight(1f))
            }

            Spacer(Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                SummaryCard("Receivable", "Rs 0", Modifier.weight(1f))
                SummaryCard("Low Stock", "0", Modifier.weight(1f))
            }

            Spacer(Modifier.height(18.dp))
            Text("Business Modules", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(10.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 20.dp)
            ) {
                items(modules) { module ->
                    ModuleCard(module) { onModuleClick(module.route) }
                }
            }
        }
    }
}

@Composable
fun SummaryCard(title: String, value: String, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.height(6.dp))
            Text(value, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        }
    }
}

@Composable
fun ModuleCard(module: Module, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(125.dp),
        shape = RoundedCornerShape(18.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(14.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(module.icon, contentDescription = module.title, modifier = Modifier.size(34.dp))
            Spacer(Modifier.height(8.dp))
            Text(module.title, fontWeight = FontWeight.Bold)
            Text(module.subtitle, fontSize = 11.sp)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ModuleScreen(
    title: String,
    subtitle: String,
    icon: ImageVector,
    onBack: () -> Unit
) {
    Scaffold(
        topBar = {
            TopAppBar(
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                title = { Text(title, fontWeight = FontWeight.Bold) }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = title, modifier = Modifier.size(64.dp))
            Spacer(Modifier.height(14.dp))
            Text(title, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text(subtitle)
            Spacer(Modifier.height(24.dp))

            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("Module ready", fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "This screen is the foundation for the $title module. " +
                        "The next development step will add forms, database storage, search, reports and actions."
                    )
                }
            }
        }
    }
}

@Composable
fun RanaTradersTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = lightColorScheme(),
        content = content
    )
}
